import boto3
import os
 
def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    instance_ids = os.environ['INSTANCE_IDS'].split(',')
    stop_instances(ec2, instance_ids)
 
def stop_instances(ec2, instance_ids):
    if not instance_ids:
        print("No instances to stop.")
        return
    
    ec2.stop_instances(InstanceIds=instance_ids)
    print('Stopped instances: ' + str(instance_ids))