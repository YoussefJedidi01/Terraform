import boto3
import os
 
def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    instance_ids = os.environ['INSTANCE_IDS'].split(',')
    start_instances(ec2, instance_ids)
 
def start_instances(ec2, instance_ids):
    if not instance_ids:
        print("No instances to start.")
        return
    
    ec2.start_instances(InstanceIds=instance_ids)
    print('Started instances: ' + str(instance_ids))